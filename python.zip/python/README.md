# E-Parduotuvės (Barbora analogas) Sistemos Ataskaita

## 1. Introduction
**What is your application?** Ši programa yra terminalinė elektroninės parduotuvės simuliacija. Ji leidžia vartotojams peržiūrėti prekių asortimentą, dėti maisto bei buities prekes į krepšelį ir sugeneruoti galutinį pirkimo kvitą.

**How to run the program?** 1. Įsitikinkite, kad turite įdiegtą Python 3.
2. Turėkite `produktai.csv` failą tame pačiame aplanke.
3. Paleiskite pagrindinį programos failą terminale: `python main.py`.
4. Testams paleisti naudokite komandą: `python -m unittest test_shop.py`.

**How to use the program?** Paleidus programą, įveskite pristatymo miestą ir gatvę. Tuomet iš matomo meniu pasirinkite prekės numerį, kurį norite pridėti į krepšelį. Norėdami baigti apsipirkimą, įveskite `0`. Programa sugeneruos `.txt` formato kvitą jūsų kompiuteryje.

## 2. Body/Analysis
Programa pilnai realizuoja objektinio programavimo (OOP) principus ir atitinka funkcinius reikalavimus:

* **Abstraction (Abstrakcija):** Sukurta abstrakti klasė `Product` naudojant `ABC` modulį. Joje apibrėžtas abstraktus metodas `get_details()`, kurį privalo realizuoti vaikinės klasės.
* **Encapsulation (Inkapsuliacija):** `Product` klasėje prekės kaina apsaugota privačiu kintamuoju `self.__price`, o pasiekiama tik per *getterį* `get_price()`.
* **Inheritance (Paveldėjimas):** Klasės `FoodProduct` ir `HouseholdProduct` paveldi bazines savybes iš `Product` klasės.
* **Polymorphism (Polimorfizmas):** Metodas `get_details()` yra perrašytas (*overridden*) abiejose vaikinėse klasėse, kad grąžintų skirtingai suformatuotą informaciją priklausomai nuo prekės tipo.

**Design Pattern:** Panaudotas **Factory Method** šablonas (`ProductFactory` klasė).  
*Kodėl jis tinkamiausias?* „In scenarios where we need different types of product objects (Food vs Household), the Factory Pattern provides a single place to instantiate them based on a string parameter from the CSV file. This keeps the CSV reading logic clean and scalable.“

**Composition and Aggregation:** * *Kompozicija:* Klasėje `Order` tiesiogiai sukuriama `Address` instancija. Jei užsakymas ištrinamas, jo pristatymo adresas taip pat praranda prasmę.
* *Agregacija:* `Order` klasė kaupia `Product` objektus sąraše `self.products`. Prekės egzistuoja parduotuvės asortimente nepriklausomai nuo to, ar jos yra užsakyme.

**File I/O:** Prekės nuskaitomos iš `produktai.csv` failo panaudojant `csv` biblioteką. Apsipirkimo pabaigoje kvitas įrašomas į dinamiškai sugeneruotą `.txt` failą.

## 3. Results and Summary
* Programa sėkmingai perskaito duomenis iš CSV failo ir paverčia juos objektais naudojant Factory šabloną.
* Vartotojo sąsaja terminale yra intuityvi, apdorojamos vartotojo įvesties klaidos (pvz., įvedus ne skaičių).
* Sėkmingai sugeneruojamas kvitas su visa reikiama informacija (adresas, prekių sąrašas, galutinė suma).
* **Iššūkiai:** Vienas iš iššūkių buvo teisingai suformatuoti kvitą ir išlaikyti lygiavimą terminale, tam panaudotas f-string formatavimas (pvz., `:<30`).

## 4. Conclusions
Šio darbo metu buvo sėkmingai įtvirtintos Python objektinio programavimo žinios. Sukurta veikianti ir lengvai plečiama e-parduotuvės sistema. 
**Ateities perspektyvos:** Programą būtų galima išplėsti pridedant duomenų bazės (pvz., SQLite) palaikymą vietoje `.csv` failo, bei sukuriant grafinę vartotojo sąsają (GUI) su `Tkinter` ar web aplikaciją su `Flask` / `FastAPI`.