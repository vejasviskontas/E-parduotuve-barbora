import csv
import os
from abc import ABC, abstractmethod
from datetime import datetime

# ==========================================
# 1. ABSTRAKCIJA IR INKAPSULIACIJA
# ==========================================
class Product(ABC):
    def __init__(self, name: str, price: float):
        self._name = name          
        self.__price = price       

    def get_price(self) -> float:
        return self.__price

    def get_name(self) -> str:
        return self._name

    @abstractmethod
    def get_details(self) -> str:
        pass

# ==========================================
# 2. PAVELDĖJIMAS IR POLIMORFIZMAS
# ==========================================
class FoodProduct(Product):
    def __init__(self, name: str, price: float, _unused_info=""):
        super().__init__(name, price)

    def get_details(self) -> str:
        return f"[Maistas] {self.get_name():<30} | Kaina: {self.get_price():>5.2f} EUR"

class HouseholdProduct(Product):
    def __init__(self, name: str, price: float, brand: str):
        super().__init__(name, price)
        self.brand = brand

    def get_details(self) -> str:
        brand_str = f"({self.brand})"
        return f"[Buitis] {self.get_name() + ' ' + brand_str:<30} | Kaina: {self.get_price():>5.2f} EUR"

# ==========================================
# 3. DIZAINO ŠABLONAS: FACTORY METHOD
# ==========================================
class ProductFactory:
    @staticmethod
    def create_product(prod_type: str, name: str, price: float, extra_info: str) -> Product:
        if prod_type == "Food":
            return FoodProduct(name, price, extra_info)
        elif prod_type == "Household":
            return HouseholdProduct(name, price, extra_info)
        else:
            raise ValueError(f"Nežinomas tipas: {prod_type}")

# ==========================================
# 4. KOMPOZICIJA IR AGREGACIJA
# ==========================================
class Address:
    def __init__(self, city: str, street: str):
        self.city = city
        self.street = street

    def __str__(self):
        return f"{self.street}, {self.city}"

class Order:
    def __init__(self, address_city: str, address_street: str):
        self.delivery_address = Address(address_city, address_street)
        self.products = []

    def add_product(self, product: Product):
        self.products.append(product)

    def get_total(self) -> float:
        return sum(p.get_price() for p in self.products)

    def generate_receipt(self):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"kvitas_{timestamp}.txt"
        full_path = os.path.join(current_dir, filename)
        
        with open(full_path, 'w', encoding='utf-8') as file:
            file.write("           BARBORA KVITAS\n")
            file.write(f"Data: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            file.write("=" * 50 + "\n")
            file.write(f"Adresas: {self.delivery_address}\n")
            file.write("-" * 50 + "\n")
            for prod in self.products:
                file.write(prod.get_details() + "\n")
            file.write("-" * 50 + "\n")
            file.write(f"IŠ VISO: {self.get_total():>35.2f} EUR\n")
            file.write("=" * 50 + "\n")
        
        print(f"\n✅ Apsipirkimas baigtas! Kvitas išsaugotas:\n{full_path}")

# ==========================================
# SKAITYMAS IŠ FAILO
# ==========================================
def load_inventory(filename: str):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, filename)
    inventory = []
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            reader = csv.reader(file)
            for row in reader:
                if len(row) >= 3:
                    p_type, p_name, p_price = row[0], row[1], float(row[2])
                    p_extra = row[3] if len(row) > 3 else ""
                    product = ProductFactory.create_product(p_type, p_name, p_price, p_extra)
                    inventory.append(product)
    except FileNotFoundError:
        print(f"Klaida: Failas {file_path} nerastas!")
    except Exception as e:
        print(f"Klaida nuskaitant failą: {e}")
    return inventory

# ==========================================
# INTERAKTYVI PROGRAMOS DALIS (TERMINALO MENIU)
# ==========================================
if __name__ == "__main__":
    # 1. Užkrauname prekes iš failo
    asortimentas = load_inventory("produktai.csv")
    
    if not asortimentas:
        print("Parduotuvė tuščia. Patikrinkite produktai.csv failą.")
        exit()

    # 2. Pasisveikiname ir surenkame pristatymo adresą
    print("\n" + "="*40)
    print("      SVEIKI ATVYKĘ Į E-PARDUOTUVĘ")
    print("="*40)
    miestas = input("Įveskite pristatymo miestą: ")
    gatve = input("Įveskite gatvę ir namo numerį: ")
    
    uzsakymas = Order(miestas, gatve)
    
    # 3. Sukuriame apsipirkimo ciklą
    while True:
        print("\n--- PREKIŲ ASORTIMENTAS ---")
        for indeksas, preke in enumerate(asortimentas, start=1):
            print(f"[{indeksas}] {preke.get_name():<25} - {preke.get_price():>5.2f} EUR")
        
        print("\n[0] BAIGTI APSIPIRKIMĄ IR APMOKĖTI")
        
        pasirinkimas = input("\nĮveskite prekės numerį, kurią norite dėti į krepšelį: ")
        
        if pasirinkimas == '0':
            break
            
        try:
            prekes_nr = int(pasirinkimas) - 1
            if 0 <= prekes_nr < len(asortimentas):
                pasirinkta_preke = asortimentas[prekes_nr]
                uzsakymas.add_product(pasirinkta_preke)
                print(f"🛒 Pridėta: {pasirinkta_preke.get_name()} (Krepšelyje: {len(uzsakymas.products)} prekių)")
            else:
                print("❌ Klaida: Tokio prekės numerio nėra. Bandykite dar kartą.")
        except ValueError:
            print("❌ Klaida: Prašome įvesti tik skaičių!")

    # 4. Kai ciklas baigiasi (įvestas 0), spausdiname sumą ir kvitą
    if len(uzsakymas.products) > 0:
        viso_moketi = uzsakymas.get_total()
        print("\n" + "="*40)
        print(f"💳 JŪSŲ KREPŠELIO SUMA: {viso_moketi:.2f} EUR")
        print("="*40)
        
        print("\nGeneruojamas Jūsų užsakymo kvitas...")
        uzsakymas.generate_receipt()
    else:
        print("\nJūsų krepšelis tuščias. Iki greito!")