import unittest
from main import ProductFactory, FoodProduct, HouseholdProduct, Order, Address

class TestParduotuve(unittest.TestCase):

    def setUp(self):
        # Susikuriam pradinius duomenis, kad nereiktu jų kartoti iš naujo kiekvieną kartą
        self.preke1 = ProductFactory.create_product("Food", "Duona", 1.50, "")
        self.preke2 = ProductFactory.create_product("Household", "Muilas", 2.00, "Dove")
        self.uzsakymas = Order("Kaunas", "Savanorių pr. 1")

    def test_factory_kuria_teisingus_objektus(self):
        self.assertIsInstance(self.preke1, FoodProduct)
        self.assertIsInstance(self.preke2, HouseholdProduct)
        self.assertEqual(self.preke1.get_name(), "Duona")
        self.assertEqual(self.preke2.brand, "Dove")

    def test_jei_blogas_tipas_meta_klaida(self):
        with self.assertRaises(ValueError):
            ProductFactory.create_product("Nesamone", "Daiktas", 10.0, "")

    def test_kainos_pasiekiamumas(self):
        # tikrinam, ar veikia getteris
        self.assertEqual(self.preke1.get_price(), 1.50)
        
        # bandom pasiekti privatų kintamąjį tiesiogiai ir tureim gaut rezultatą, kad nepasieks
        with self.assertRaises(AttributeError):
            _ = self.preke1.__price

    def test_krepselio_sumos_skaiciavimas(self):
        # pradžioje krepselis tuscias
        self.assertEqual(self.uzsakymas.get_total(), 0.0)
        
        self.uzsakymas.add_product(self.preke1)
        self.uzsakymas.add_product(self.preke2)
        
        self.assertEqual(len(self.uzsakymas.products), 2)
        self.assertEqual(self.uzsakymas.get_total(), 3.50)

    def test_adreso_sukurimas(self):
        self.assertIsInstance(self.uzsakymas.delivery_address, Address)
        self.assertEqual(self.uzsakymas.delivery_address.city, "Kaunas")

    def test_polimorfizmas_skirtingas_tekstas(self):
        tekstas1 = self.preke1.get_details()
        tekstas2 = self.preke2.get_details()
        
        # Maisto prekei turi prirasyti [Maistas], o buiciai - jos branda
        self.assertIn("[Maistas]", tekstas1)
        self.assertIn("[Buitis]", tekstas2)
        self.assertIn("Dove", tekstas2)

if __name__ == '__main__':
    unittest.main()